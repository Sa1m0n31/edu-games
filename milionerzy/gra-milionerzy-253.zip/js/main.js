const questions = [
        [
            {
                question: '',
                right: 'Aunque hacía mucho frío, me comí un helado.',
                wrong1: 'Aunque había muchos helados, me comí el hielo',
                wrong2: 'Aunque había mucho hielo, me comí la nieve.',
                wrong3: 'Aunque hacía mucho calor, me comí el hielo.',
                img: './assets/img1.jpg'
            },
            {
                question: '',
                right: 'La temperatura es muy baja.',
                wrong1: 'La nieve está desapareciendo.',
                wrong2: 'No hay temperatura.',
                wrong3: 'La temperatura es muy alta.',
                img: './assets/img2.jpg'
            },
            {
                question: 'En las zonas más frías del país hay mucha nieve y la temperatura mínima puede llegar a ser de quince grados…',
                right: 'bajo cero.',
                wrong1: 'positivos.',
                wrong2: 'de altura.',
                wrong3: 'sobre cero.'
            },
            {
                question: 'Si hay hielo en el suelo es peligroso porque te puedes…',
                right: 'resbalar.',
                wrong1: 'saltar.',
                wrong2: 'conversar.',
                wrong3: 'tumbar.'
            },
            {
                question: 'El granizo son…',
                right: 'pequeñas bolitas de hielo que caen del cielo.',
                wrong1: 'vientos muy fuertes.',
                wrong2: 'gotas de agua fría.',
                wrong3: 'copos de nieve derretidos.'
            }
        ],
        [
            {
                question: '',
                right: 'Ella tenía frío, por eso se cubrió el cuello con una bufanda.',
                wrong1: 'Ella tenía frío, por eso se cubrió la cabeza con un gorro.',
                wrong2: 'Como la temperatura era baja, ella se puso guantes.',
                wrong3: 'Hacía menos de cero grados, por eso ella se quitó la bufanda.',
                img: './assets/img3.jpg'
            },
            {
                question: 'Cuando no se puede ver bien porque parece que hay nubes al nivel del suelo decimos que hay…',
                right: 'niebla.',
                wrong1: 'hielo.',
                wrong2: 'nieve.',
                wrong3: 'tormenta.'
            },
            {
                question: '',
                right: 'El lago se ha congelado.',
                wrong1: 'El barco se ha hundido.',
                wrong2: 'El agua se ha derretido.',
                wrong3: 'Está nevando en este momento.',
                img: './assets/img4.jpg'
            },
            {
                question: '',
                right: 'Para esquiar es necesario tener un equipamiento adecuado.',
                wrong1: 'La práctica del esquí está prohibida en zonas de montaña.',
                wrong2: 'El hombre está practicando un deporte acuático.',
                wrong3: 'En invierno no hace suficiente frío para esquiar.',
                img: './assets/img5.jpg'
            },
            {
                question: 'Una tormenta de nieve también puede llamarse…',
                right: 'ventisca.',
                wrong1: 'helada.',
                wrong2: 'nevada.',
                wrong3: 'granizo.'
            }
        ],
    [
        {
            question: '',
            right: 'Esta máquina se llama “quitanieves”.',
            wrong1: 'Esta máquina se llama “ventilador”.',
            wrong2: 'Esta máquina se llama “invernadero”.',
            wrong3: 'Esta máquina se llama “carretera”.',
            img: './assets/img6.jpg'
        },
        {
            question: 'En España, podemos encontrar nieve en…',
            right: 'las zonas de alta montaña.',
            wrong1: 'las áreas desérticas del sur.',
            wrong2: 'la costa.',
            wrong3: 'las zonas insulares.'
        },
        {
            question: 'Una avalancha es…',
            right: 'una gran cantidad de nieve que se desliza rápidamente por la montaña.',
            wrong1: 'una tormenta con nieve y relámpagos.',
            wrong2: 'una lluvia muy fría que solo se produce en invierno.',
            wrong3: 'una nevada muy fuerte que bloquea las carreteras.',
        },
        {
            question: '',
            right: 'En invierno podemos utilizar un trineo.',
            wrong1: 'Cuando hay nieve podemos usar un patinete.',
            wrong2: 'A los niños les encanta usar un velero en la nieve.',
            wrong3: 'En invierno, mucha gente usa el teleférico para desplazarse.',
            img: './assets/img7.jpg'
        },
        {
            question: 'Hacía mucho frío, por eso el agua de mi botella…',
            right: 'se congeló.',
            wrong1: 'El primer submarino podía volar.',
            wrong2: 'El primer submarino no podía tocar el agua.',
            wrong3: 'El submarino se diseñó para poder navegar bajo el agua.'
        }
    ]
]

/* Play audio in background */
let audio;
document.addEventListener("click", () => {
    audio = new Audio('./assets/podklad.wav');
    audio.play();
    audio.volume = 0.07;
    audio.loop = true;
}, { once: true });

const progress = [7, 13, 20, 27, 33, 40, 47, 53, 60, 67, 73, 80, 87, 93, 100];
// const progress = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
// const progress = [8, 17, 25, 33, 42, 50, 58, 67, 75, 83, 92, 100];
// const progress = [11, 22, 33, 44, 56, 67, 78, 89, 100];

/* Randomize questions */
const shuffleArray = (array) => {
    let currentIndex = array.length,  randomIndex;

    // While there remain elements to shuffle...
    while (currentIndex !== 0) {

        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;

        // And swap it with the current element.
        [array[currentIndex], array[randomIndex]] = [
            array[randomIndex], array[currentIndex]];
    }

    return array;
}

let currentLvl = 0;
let gameOver = false;
let helpAvailable = 2;

let lvl1Questions = shuffleArray(questions[0]);
let lvl2Questions = shuffleArray(questions[1]);
let lvl3Questions = shuffleArray(questions[2]);

const intro = document.querySelector(".view--start");
const questionImg = document.querySelector(".view--question");

const rightAnswerMarker = document.querySelector(".img--right");
const wrongAnswerMarker = document.querySelector(".img--wrong");

const feedbackRight = document.querySelector(".feedbackWrapper--right");
const feedbackWrong = document.querySelector(".feedbackWrapper--wrong");
const feedbackRightPercentPlaceholder = document.querySelector(".feedbackWrapper--right__percent");

const helpBtn = document.querySelector(".help");
const endOfTheGame = document.querySelector(".view--end");

setTimeout(() => {
    intro.style.display = "none";
    questionImg.style.display = "block";
}, 2000);

const questionPlaceholder = document.querySelector(".question");
const answer1Placeholder = document.querySelector(".answer--1");
const answer2Placeholder = document.querySelector(".answer--2");
const answer3Placeholder = document.querySelector(".answer--3");
const answer4Placeholder = document.querySelector(".answer--4");
const image = document.querySelector(".image");

const answerPlaceholders = [answer1Placeholder, answer2Placeholder, answer3Placeholder, answer4Placeholder];
// const answerPlaceholders = [answer1Placeholder, answer2Placeholder, answer3Placeholder];

const enableAllAnswers = () => {
    answerPlaceholders.forEach((item) => {
        item.removeAttribute("disabled");
    });
}

const playAgain = () => {
    lvl1Questions = shuffleArray(questions[0]);
    lvl2Questions = shuffleArray(questions[1]);
    lvl3Questions = shuffleArray(questions[2]);

    feedbackWrong.style.opacity = "0";
    feedbackWrong.style.display = "none";
    wrongAnswerMarker.style.display = "none";

    helpBtn.style.display = "block";

    gameOver = false;
    currentLvl = 0;
    helpAvailable = 2;

    enableAllAnswers();
    nextLvl();
}

const markRightAnswer = (position) => {
    rightAnswerMarker.style.display = "block";

    rightAnswerMarker.removeAttribute('class');
    rightAnswerMarker.classList.add('img--right');
    rightAnswerMarker.classList.add(`img--mark--${position}`);

    feedbackRight.style.display = "block";
    feedbackRight.style.opacity = "1";

    feedbackRightPercentPlaceholder.textContent = progress[currentLvl-1].toString();

    setTimeout(() => {
        nextLvl();
    }, 2000);
}

const markWrongAnswer = (position) => {
    wrongAnswerMarker.style.display = "block";

    wrongAnswerMarker.removeAttribute('class');
    wrongAnswerMarker.classList.add('img--wrong');
    wrongAnswerMarker.classList.add(`img--mark--${position}`);
    wrongAnswerMarker.classList.add(`img--mark--${position}--wrong`);

    feedbackWrong.style.display = "block";
    feedbackWrong.style.opacity = "1";

    gameOver = true;

    setTimeout(() => {
        playAgain();
    }, 3000);
}

const checkAnswer = (e, position) => {
    if(!gameOver) {
        image.style.display = "none";

        const selectedAnswer = e.textContent;
        const currentQuestionObject = getCurrentQuestionObject();

        if(selectedAnswer === currentQuestionObject.right) {
            markRightAnswer(position);
        }
        else {
            markWrongAnswer(position);
        }
    }
}

const getCurrentQuestionObject = () => {
    if(currentLvl < 6) return lvl1Questions[currentLvl-1];
    else if(currentLvl < 11) return lvl2Questions[(currentLvl-1)%5];
    else return lvl3Questions[(currentLvl-1)%5];
}

const nextLvl = () => {
    currentLvl++;

    if(currentLvl < 16) {
        enableAllAnswers();

        rightAnswerMarker.style.display = "none";
        wrongAnswerMarker.style.display = "none";
        feedbackRight.style.opacity = "0";
        feedbackRight.style.display = "none";

        const currentQuestionObject = getCurrentQuestionObject();

        for(let i=1; i<=2; i++) {
            rightAnswerMarker.classList.remove(`img--mark--${i}`);

            wrongAnswerMarker.classList.remove(`img--mark--${i}`);
            wrongAnswerMarker.classList.remove(`img--mark--${i}--wrong`);
        }

        const { question, right, wrong1, wrong2, wrong3 } = currentQuestionObject;
        questionPlaceholder.textContent = question;
        const currentQuestionAnswers = [right, wrong1, wrong2, wrong3];
        const shuffledAnswers = shuffleArray(currentQuestionAnswers);

        answer1Placeholder.textContent = shuffledAnswers[0];
        answer2Placeholder.textContent = shuffledAnswers[1];
        answer3Placeholder.textContent = shuffledAnswers[2];
        answer4Placeholder.textContent = shuffledAnswers[3];

        if(currentQuestionObject.img) {
            image.style.display = "block";
            image.setAttribute("src", currentQuestionObject.img);
        }
        else image.style.display = "none";
    }
    else {
        endOfTheGame.style.display = "flex";
        audio.pause();
    }
}

const excludeTwoAnswers = () => {
    helpAvailable--;
    if(helpAvailable <= 0) {
        helpBtn.style.display = "none";
    }

    const { wrong1, wrong2, wrong3 } = getCurrentQuestionObject();
    const wrongAnswers = [wrong1, wrong2, wrong3];
    const shuffledWrongAnswers = shuffleArray(wrongAnswers);

    const answerToExclude1 = shuffledWrongAnswers[0];
    const answerToExclude2 = shuffledWrongAnswers[1];

    answerPlaceholders.forEach((item) => {
       if((item.textContent === answerToExclude1)||(item.textContent === answerToExclude2)) {
            item.textContent = "";
            item.setAttribute("disabled", "true");
       }
    });
}

/* Start the game */
nextLvl();
