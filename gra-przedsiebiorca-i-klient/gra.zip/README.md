# Gra przedsiębiorca i klient
Simple education game about entrepreneurship, setting up company and client's behaviour
<br/>
<br/>
<b>Stack:</b> HTML, CSS, Javascript
<br/>
<b>Libraries:</b> Siema.js
