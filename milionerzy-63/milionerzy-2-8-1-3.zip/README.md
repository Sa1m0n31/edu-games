# Milionerzy
Quiz game in Spanish based on TV series "Milionerzy"
<br/>
<br/>
<b>Stack:</b> HTML, CSS, Javascript