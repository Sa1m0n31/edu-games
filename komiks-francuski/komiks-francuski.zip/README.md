# French comics
Simple Javascript comics for French learners
<br/>
<br/>
<b>Stack:</b> HTML, CSS, Javascript
<br/>
<b>Libraries:</b> Siema.js
